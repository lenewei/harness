﻿using Microsoft.Data.SqlClient;
using System;

namespace integration_test_app
{
   public class SQLServer
   {
      public static void GetConnection()
      {
         var connectionString = Environment.GetEnvironmentVariable("SQLSERVER_CONNECTION_STRING");
         try
         {
            using var connection = new SqlConnection(connectionString);
            connection.Open();
            connection.Close();
         }
         catch (Exception ex)
         {
            Console.WriteLine($"Failed to connect to Redis {connectionString}. Error: ${ex.Message}");
         }

      }
   }
}
