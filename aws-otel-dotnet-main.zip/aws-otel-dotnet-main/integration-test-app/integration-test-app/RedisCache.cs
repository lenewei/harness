﻿using StackExchange.Redis;
using System;

namespace integration_test_app
{
   public class RedisCache
   {
      public static void GetConnection()
      {
         var address = new Uri(Environment.GetEnvironmentVariable("REDIS_ENDPOINT"));
         if (address == null)
            throw new Exception($"Failed to interpret the address {Environment.GetEnvironmentVariable("REDIS_ENDPOINT")}");
         try
         {
            var connection = ConnectionMultiplexer.Connect(address.AbsolutePath);
         }
         catch (Exception ex)
         {
            Console.WriteLine($"Failed to connect to Redis {address.AbsolutePath}. Error: ${ex.Message}");
         }
      }
   }
}
